
<?php $__env->startSection('title', 'Blog Details'); ?>
<?php $__env->startSection('user-content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-9">
                <br>
                <h1><?php echo e($blog->title); ?></h1>
                <img style="width:100%;" src="<?php echo e(asset($blog->image)); ?>" alt="">
                <div><?php echo e($blog->description); ?></div>
            </div>
            <div class="col-md-3">
                <div class="other-blog mt-5">
                    <h3>Latest Blog</h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\naim\resources\views/singleBlog.blade.php ENDPATH**/ ?>