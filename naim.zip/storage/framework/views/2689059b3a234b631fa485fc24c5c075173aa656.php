
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startPush('admin-css'); ?>
    <style>
        a {
            text-decoration: none !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
    </ul>
</div>
<div class="row">
    <div class="col-md-6 col-lg-3">
        <a href="<?php echo e(route('service.index')); ?>">
            <div class="widget-small primary coloured-icon">
                <i class="icon fa fa-briefcase fa-3x"></i>
                <div class="info">
                    <h4>Services</h4>
                    <p><b><?php echo e($services); ?></b></p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-3">
        <a href="<?php echo e(route('contact.index')); ?>">
            <div class="widget-small info coloured-icon">
                <i class="icon fa fa-envelope fa-3x"></i>
                <div class="info">
                    <h4>Contact</h4>
                    <p><b><?php echo e($contact); ?></b></p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-3">
        <a href="<?php echo e(route('portfolio.index')); ?>">
            <div class="widget-small warning coloured-icon">
                <i class="icon fa fa-files-o fa-3x"></i>
                <div class="info">
                    <h4>Projects</h4>
                    <p><b><?php echo e($portfolio); ?></b></p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-3">
        <a href="<?php echo e(route('logout')); ?>">
            <div class="widget-small danger coloured-icon">
                <i class="icon fa fa-power-off fa-3x"></i>
                <div class="info">
                    <h4>Logout</h4>
                </div>
            </div>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\naim\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>