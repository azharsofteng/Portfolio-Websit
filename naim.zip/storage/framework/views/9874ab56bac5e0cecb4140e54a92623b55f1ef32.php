
<?php $__env->startSection('title','Blog Create'); ?>
<?php $__env->startPush('admin-css'); ?>
<link href="<?php echo e(asset('summernote/summernote-bs4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-briefcase"></i> &nbsp; Add New Blog Post</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
        <li class="breadcrumb-item active"><a class="btn btn-info btn-sm" href="<?php echo e(route('blog.index')); ?>">Blog list</a></li>
    </ul>
</div>
<div class="row">
    <div class="col-md-12">
        <form method="POST" action="<?php echo e(route('blog.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="tile">
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group row">
                    <label class="col-md-3" for="title">Blog Title <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title')); ?>" placeholder="Enter Blog Title">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div> 
                <div class="form-group row mt-2">
                    <label class="col-md-3" for="date">Blog Date <span class="text-danger">*</span></label>
                    <div class="col-md-9">
                        <input name="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date" type="date" value="<?php echo e(date("Y-m-d")); ?>">
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>  
                <div class="form-group mt-2">
                    <label for="is_feature"><input type="checkbox" name="is_feature" id="is_feature" checked value="1"> <span class="ml-2">Is Feature</span></label>
                    
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group row">
                    <label class="col-md-3" for="image">Blog Image </label>
                    <div class="col-md-9">
                        <input class="form-control" id="image" type="file" name="image" onchange="readURL(this);">
                        <div class="form-group mt-1">
                            <img class="form-controlo img-thumbnail" src="#" id="previewImage" style="width: 100px;height: 80px; background: #3f4a49;">
                        </div>
                    </div>  
                </div> 
            </div>
            <div class="col-md-12">
                <label for="summernote">Blog Description</label>
                <textarea name="description"  id="summernote" placeholder="Enter Blog Description"></textarea>
            </div>
        </div>
        <div class="tile-footer text-right">
            <button class="btn btn-primary " type="submit">Create</button>
        </div>
        </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('summernote/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernote').summernote({
        tabsize: 2,
        height: 200
    });
</script>
<script>
    function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#previewImage')
                .attr('src', e.target.result)
                .width(100)
                .height(80);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    document.getElementById("previewImage").src="/default.png";
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\naim\resources\views/admin/blog/create.blade.php ENDPATH**/ ?>