<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

        <title>OhiduzzamanIt | <?php echo $__env->yieldContent('title'); ?></title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
        <!-- Fonts -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome.min.css')); ?>" />
        <!-- Icon -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/simple-line-icons.css')); ?>" />
        <!-- Slicknav -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slicknav.css')); ?>" />
        <!-- Nivo Lightbox -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/nivo-lightbox.css')); ?>" />
        <!-- Animate -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>" />
        <!-- Main Style -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>" />
        <!-- Responsive Style -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />
        <style>
            .hero-area-bg {
                background: url("<?php echo e(asset($about->cover_picture)); ?>") no-repeat;
                background-size: cover;
            }
        </style>
    </head>
    <body>
        <!-- Header Area wrapper Starts -->
        <header id="header-wrap">
            <!-- Navbar Start -->
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Navbar End -->

        </header>
        <!-- Header Area wrapper End -->

        <?php echo $__env->yieldContent('user-content'); ?>

        <!-- Footer Section Start -->
            <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer Section End -->

        <!-- Go to Top Link -->
        <a href="#" class="back-to-top">
            <i class="icon-arrow-up"></i>
        </a>

        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="<?php echo e(asset('js/jquery-min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.mixitup.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.nav.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/nivo-lightbox.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\naim\resources\views/layouts/website-master.blade.php ENDPATH**/ ?>