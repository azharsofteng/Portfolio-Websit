
<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="blog" class="mb-5" style="margin-top: 60px;">
    <div class="blog-cover">
        <h4 class="text-white text-center"><a class="text-white" href="<?php echo e(route('home')); ?>">Home</a> / Blog</h4>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mt-4">
                <div class="card blog-card">
                    <img style="height: 200px;" src="<?php echo e(asset($blog->image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body blog-body">
                        <h5 class="card-title"><?php echo e($blog->title); ?></h5>
                        <div>
                            <?php echo Str::limit($blog->description, 120, '...'); ?>

                        </div>
                        <a href="<?php echo e(route('single-blog', $blog->slug)); ?>" class="btn btn-info btn-sm mt-2">Read more</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\naim\resources\views/blog.blade.php ENDPATH**/ ?>