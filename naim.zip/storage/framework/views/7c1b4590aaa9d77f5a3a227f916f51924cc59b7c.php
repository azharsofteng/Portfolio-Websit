
<?php $__env->startSection('title', 'Blog Details'); ?>
<?php $__env->startSection('user-content'); ?>
    <div class="single-blog" class="mb-5" style="margin-top: 60px;">
        <div class="single-blog-cover">
            <h4 class="text-white text-center"><a class="text-white" href="<?php echo e(route('home')); ?>">Home</a> / Blog Details</h4>
        </div>
        <div class="container mb-4">
            <div class="row">
                <div class="col-md-9">
                    <br>
                    <h3 class="single-title mb-0"><?php echo e($blog->title); ?></h3>
                    <p><i class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d-m-Y / h:i:s A')); ?></p>
                    <img style="width:100%;" src="<?php echo e(asset($blog->image)); ?>" alt="">
                    <div class="mt-2"><?php echo $blog->description; ?></div>
                    <h5 class="mt-3">Social Media Share:</h5>
                    <hr class="mt-2 mb-3">
                    
                    <div class="social">
                        <div class="outlineSocialShare">
                            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://naim.test/<?php echo e(Request::path()); ?>"><i class="fa fa-facebook"></i></a>
                            <a target="_blank" href="http://twitter.com/share?url=http://naim.test/<?php echo e(Request::path()); ?>"><i class="fa fa-twitter"></i></a>
                            <a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=http://naim.test/<?php echo e(Request::path()); ?>"><i class="fa fa-linkedin"></i></a>
                            <a target="_blank" href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="other-blog mt-5">
                        <h3 class="single-title">Latest Blog</h3>
                        <?php $__currentLoopData = $latestBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="latest-blog card mb-2">
                            <div class="row">
                                <div class="col-md-6">
                                    <img style="width:100%; min-height:90px;" src="<?php echo e(asset($item->image)); ?>" alt="">
                                </div>
                                <div class="col-md-6 p-0">
                                    <a class="latest-title" href="<?php echo e(route('single-blog', $item->slug)); ?>"><?php echo e(Str::limit($item->title, 40)); ?></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\naim\resources\views/singleBlog.blade.php ENDPATH**/ ?>