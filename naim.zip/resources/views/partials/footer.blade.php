<footer class="footer-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="footer-text text-center wow fadeInDown" data-wow-delay="0.3s">
                    <ul class="social-icon">
                        <li>
                            <a class="facebook" href="#"><i class="icon-social-facebook"></i></a>
                        </li>
                        <li>
                            <a class="twitter" href="#"><i class="icon-social-twitter"></i></a>
                        </li>
                        <li>
                            <a class="instagram" href="#"><i class="icon-social-instagram"></i></a>
                        </li>
                        <li>
                            <a class="instagram" href="#"><i class="icon-social-linkedin"></i></a>
                        </li>
                        <li>
                            <a class="instagram" href="#"><i class="icon-social-google"></i></a>
                        </li>
                    </ul>
                    <p>Copyright © {{ date('Y') }} OhiduzzamanIt All Right Reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>